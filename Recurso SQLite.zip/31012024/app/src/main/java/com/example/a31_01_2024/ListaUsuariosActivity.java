package com.example.a31_01_2024;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.List;

public class ListaUsuariosActivity extends AppCompatActivity {

    ListView listView;
    PersonDAO personDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_usuarios);

        listView = findViewById(R.id.listView);
        personDAO = new PersonDAO(this);

        List<Person> people = personDAO.getAllPeople();

        String[] userNames = new String[people.size()];
        for (int i = 0; i < people.size(); i++) {
            userNames[i] = people.get(i).getName() + " - " + people.get(i).getEmail();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, userNames);
        listView.setAdapter(adapter);
    }
}
