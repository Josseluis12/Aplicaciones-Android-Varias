package com.example.a31_01_2024;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editTextName, editTextEmail;
    Button buttonGuardar, buttonVerLista;
    PersonDAO personDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        editTextEmail = findViewById(R.id.editTextEmail);
        buttonGuardar = findViewById(R.id.buttonGuardar);
        buttonVerLista = findViewById(R.id.buttonVerLista);
        personDAO = new PersonDAO(this);

        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                String email = editTextEmail.getText().toString();

                if (!name.isEmpty() && !email.isEmpty()) {
                    Person person = new Person(0, name, email);
                    long result = personDAO.insertPerson(person);
                    if (result != -1) {
                        editTextName.setText("");
                        editTextEmail.setText("");
                        showToast("Usuario guardado correctamente");
                    } else {
                        showToast("Error al guardar el usuario");
                    }
                } else {
                    showToast("Por favor, completa todos los campos");
                }
            }
        });

        buttonVerLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListaUsuariosActivity.class);
                startActivity(intent);
            }
        });
    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
