package com.example.a31_01_2024;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;


import java.util.ArrayList;
import java.util.List;

public class PersonDAO {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public PersonDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
        open();
    }

    public void open() throws SQLException {
        try {
            database = dbHelper.getWritableDatabase();
            Log.d("PersonDAO", "Base de datos abierta correctamente");
        } catch (SQLException e) {
            Log.e("PersonDAO", "Error al abrir la base de datos: " + e.getMessage());
            throw e;
        }
    }

    public void close() {
        dbHelper.close();
    }

    public long insertPerson(Person person) {
        ContentValues values = new ContentValues();
        values.put("name", person.getName());
        values.put("email", person.getEmail());

        return database.insert("people", null, values);
    }

    public List<Person> getAllPeople() {
        List<Person> people = new ArrayList<>();

        Cursor cursor = database.query("people", null, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Person person = cursorToPerson(cursor);
            people.add(person);
            cursor.moveToNext();
        }

        cursor.close();
        return people;
    }

    private Person cursorToPerson(Cursor cursor) {
        int id = cursor.getInt(cursor.getColumnIndex("id"));
        String name = cursor.getString(cursor.getColumnIndex("name"));
        String email = cursor.getString(cursor.getColumnIndex("email"));

        return new Person(id, name, email);
    }
}
